package net.fabricmc.api;

public enum EnvType {
    CLIENT,
    SERVER
}
