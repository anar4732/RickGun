package team.creative.creativecore.client.render.model;

public interface BlockInfoExtension {
    
    public void setCustomTint(int tint);
    
}