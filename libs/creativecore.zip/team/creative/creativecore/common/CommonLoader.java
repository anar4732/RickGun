package team.creative.creativecore.common;

public interface CommonLoader {
    
    void onInitialize();
    
}
