package team.creative.creativecore.common.config.api;

import team.creative.creativecore.Side;

public interface ICreativeConfig {
    
    public void configured(Side side);
    
}
