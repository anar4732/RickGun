package team.creative.creativecore.common.config.premade.curve;

public interface Curve {
    
    public double valueAt(double x);
    
}
