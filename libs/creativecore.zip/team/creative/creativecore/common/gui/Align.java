package team.creative.creativecore.common.gui;

public enum Align {
    
    LEFT,
    CENTER,
    RIGHT,
    STRETCH;
    
}
