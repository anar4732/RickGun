package team.creative.creativecore.common.gui;

public enum VAlign {
    
    TOP,
    CENTER,
    BOTTOM,
    STRETCH;
    
}
