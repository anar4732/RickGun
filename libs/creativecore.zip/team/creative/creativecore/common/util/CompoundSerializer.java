package team.creative.creativecore.common.util;

import net.minecraft.nbt.CompoundTag;

public interface CompoundSerializer {
    
    public CompoundTag write();
    
}
