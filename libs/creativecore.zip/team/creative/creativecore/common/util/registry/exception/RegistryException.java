package team.creative.creativecore.common.util.registry.exception;

public class RegistryException extends Exception {
    
    public RegistryException(String msg) {
        super(msg);
    }
    
}
