package team.creative.creativecore.common.util.text;

import team.creative.creativecore.client.render.text.CompiledText;

public interface ITextCollection {
    
    public CompiledText[] build();
    
}
