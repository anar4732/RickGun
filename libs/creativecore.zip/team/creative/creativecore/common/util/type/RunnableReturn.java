package team.creative.creativecore.common.util.type;

@FunctionalInterface
public interface RunnableReturn {
    
    public boolean run();
    
}
