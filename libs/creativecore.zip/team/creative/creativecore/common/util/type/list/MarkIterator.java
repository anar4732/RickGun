package team.creative.creativecore.common.util.type.list;

import java.util.Iterator;

public interface MarkIterator<T> extends Iterator<T> {
    
    public void mark();
    
}
